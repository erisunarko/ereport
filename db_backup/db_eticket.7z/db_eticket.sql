-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2018 at 01:55 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_eticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_tickets`
--

CREATE TABLE `tb_tickets` (
  `ticket_id` int(5) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `service_by` text NOT NULL,
  `progress` text NOT NULL,
  `status` text NOT NULL,
  `due_date` datetime NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_tickets`
--

INSERT INTO `tb_tickets` (`ticket_id`, `title`, `description`, `service_by`, `progress`, `status`, `due_date`, `date_created`, `date_modified`) VALUES
(1, 'title', 'desc', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:12:01', '2018-10-24 06:12:01'),
(2, 'title', 'ft', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:13:00', '2018-10-24 06:13:00'),
(3, 'mkmkm', 'mmkmkm', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:14:54', '2018-10-24 06:14:54'),
(4, 'mkmkm', 'mmkmkm', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:20:51', '2018-10-24 06:20:51'),
(5, 'mkmkm', 'mmkmkm', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:20:54', '2018-10-24 06:20:54'),
(6, 'mkmkm', 'mmkmkm', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:20:58', '2018-10-24 06:20:58'),
(7, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:29:37', '2018-10-24 06:29:37'),
(8, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:35:20', '2018-10-24 06:35:20'),
(9, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:36:06', '2018-10-24 06:36:06'),
(10, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:36:41', '2018-10-24 06:36:41'),
(11, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:36:44', '2018-10-24 06:36:44'),
(12, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:42:40', '2018-10-24 06:42:40'),
(13, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:43:06', '2018-10-24 06:43:06'),
(14, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:43:37', '2018-10-24 06:43:37'),
(15, 'koko', 'kiki', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:44:24', '2018-10-24 06:44:24'),
(16, 'jarwo', 'koko\r\n', '', '', '', '0000-00-00 00:00:00', '2018-10-24 06:44:41', '2018-10-24 06:44:41'),
(17, 'tes', 'tes', 'not yet processed', 'not yet processed', 'open', '0000-00-00 00:00:00', '2018-10-24 06:47:51', '2018-10-24 06:47:51'),
(18, 'tttt', 'dddd', 'not yet processed', 'not yet processed', 'open', '0000-00-00 00:00:00', '2018-10-25 06:24:47', '2018-10-25 06:24:47'),
(19, 'tt', 'dd', 'not yet processed', 'not yet processed', 'open', '0000-00-00 00:00:00', '2018-10-25 06:26:12', '2018-10-25 06:26:12'),
(20, 'sdgsa', 'asfasf', 'not yet processed', 'not yet processed', 'open', '0000-00-00 00:00:00', '2018-10-25 06:33:37', '2018-10-25 06:33:37'),
(21, '212', '21', 'not yet processed', 'not yet processed', 'open', '0000-00-00 00:00:00', '2018-10-25 07:15:46', '2018-10-25 07:15:46'),
(22, 'repari', 'pair', 'not yet processed', 'not yet processed', 'open', '0000-00-00 00:00:00', '2018-10-26 06:30:58', '2018-10-26 06:30:58');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `employee_id` varchar(5) NOT NULL,
  `employee_name` text NOT NULL,
  `employee_password` varchar(255) NOT NULL,
  `employee_position` varchar(25) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`employee_id`, `employee_name`, `employee_password`, `employee_position`, `date_created`, `date_modified`) VALUES
('admin', 'administrator', '$2y$10$j6ylcXTFKUgWhjLHtsEiweBr.DEyg64opx92BoL8Mq/xnkQaYg5b6', 'administrator', '2018-10-21 00:00:00', '2018-10-21 00:00:00'),
('EM001', 'it_manager', '$2y$10$j6ylcXTFKUgWhjLHtsEiweBr.DEyg64opx92BoL8Mq/xnkQaYg5b6', 'it_manager', '2018-10-22 00:00:00', '2018-10-22 00:00:00'),
('EM002', 'it_admin', '$2y$10$j6ylcXTFKUgWhjLHtsEiweBr.DEyg64opx92BoL8Mq/xnkQaYg5b6', 'it_admin', '2018-10-22 00:00:00', '2018-10-22 00:00:00'),
('EM003', 'it_support', '$2y$10$j6ylcXTFKUgWhjLHtsEiweBr.DEyg64opx92BoL8Mq/xnkQaYg5b6', 'it_support', '2018-10-22 00:00:00', '2018-10-22 00:00:00'),
('EM004', 'employee', '$2y$10$j6ylcXTFKUgWhjLHtsEiweBr.DEyg64opx92BoL8Mq/xnkQaYg5b6', 'employee', '2018-10-22 00:00:00', '2018-10-22 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_tickets`
--
ALTER TABLE `tb_tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_tickets`
--
ALTER TABLE `tb_tickets`
  MODIFY `ticket_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
